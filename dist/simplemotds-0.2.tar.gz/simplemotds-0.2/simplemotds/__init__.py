#!/usr/bin/env python
from .simplemotds import *
